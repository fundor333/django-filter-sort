from django.apps import AppConfig


class FilterSorterConfig(AppConfig):
    name = 'filter_sorter'
