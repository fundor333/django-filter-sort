# Filter Sort

Filter Sort is a simple Django app to create class view with sorting and ordering.

## Quick start
